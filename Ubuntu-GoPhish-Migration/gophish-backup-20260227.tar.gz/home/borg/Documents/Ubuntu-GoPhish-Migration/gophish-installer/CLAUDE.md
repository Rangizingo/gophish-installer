# CLAUDE.md

This file provides guidance to Claude Code when working with this repository.

## Project Overview

**gophish-installer** - GoPhish phishing simulation platform deployment and campaign management toolkit.

## Purpose

Automate complete GoPhish setup:
- Check/install prerequisites (Docker Desktop, WSL2, etc.)
- Deploy GoPhish via Docker container
- Configure for first use
- Provide ready-to-campaign environment
- Deploy and manage phishing simulation campaigns
- Email delivery diagnostics for M365/Google Workspace
- Migrate to Oracle Cloud Always Free tier for permanent hosting

## Target Environment

- **OS:** Windows 10/11, Linux (Ubuntu/Pop!_OS/Debian/Fedora/Arch)
- **Users:** IT department (1-5 machines)
- **Compliance:** PCI-DSS, SOC2

## Architecture

```
install-gophish.ps1 / install-gophish.sh
├── Prerequisites check (Docker, WSL2/systemd, Chocolatey/apt)
├── Install missing components
├── Pull GoPhish Docker image
├── Configure container with default volumes
├── Start services
├── Display access credentials
└── Optional: Set up permanent Cloudflare Tunnel
```

## Commands

### Windows (PowerShell)
```powershell
# Run installer (requires admin)
.\install-gophish.ps1

# Check status
.\install-gophish.ps1 -CheckOnly

# Uninstall
.\install-gophish.ps1 -Uninstall

# Set up Cloudflare Tunnel only
.\install-gophish.ps1 -TunnelOnly
```

### Linux (Bash)
```bash
# Run installer
./install-gophish.sh

# Check status
./install-gophish.sh --check

# Uninstall
./install-gophish.sh --uninstall

# Set up Cloudflare Tunnel only
./install-gophish.sh --tunnel
```

## Key Design Decisions

- **Chocolatey** for package management (not winget)
- **Default Docker volumes** for data persistence
- **Idempotent** - safe to run multiple times
- **Verbose logging** for IT troubleshooting

## Security Considerations

- Script requires admin elevation
- GoPhish API key hardcoded in scripts (rotate after engagement)
- Default admin password must be changed on first login
- Campaign data contains sensitive employee info - handle with care
- Only use for authorized security awareness testing

## Email Admin GUI

Cross-platform GUI tools for managing phishing campaigns and M365 email delivery.

### Windows: `email-admin-gui.ps1`
WinForms-based GUI with full M365 integration.

```powershell
# From cmd.exe (required - not PowerShell ISE):
powershell -STA -ExecutionPolicy Bypass -File .\email-admin-gui.ps1
```

### Linux: `email-admin-gui-linux.py`
Python Tkinter GUI with equivalent functionality.

```bash
cd ~/Documents/AI/gophish-installer
python3 email-admin-gui-linux.py
```

**Requirements:** `sudo apt install python3-tk`

### GUI Sections & Buttons

#### Exchange Online Connection
| Button | Description |
|--------|-------------|
| Connect Exchange | OAuth browser auth to Exchange Online (required for email management buttons) |
| Disconnect | Close Exchange Online session |
| Clear Output | Clear terminal output panel |

#### Quarantine Management
| Button | Description |
|--------|-------------|
| Check Quarantine | List all quarantined emails from sender (last 7 days) with recipient, type, time, policy |
| Release ALL | Release all quarantined phishing sim emails to all recipients |
| Release Kevin+Matt | Release only kmarchese@ and mfrank@ quarantined emails |

#### Diagnostics
| Button | Description |
|--------|-------------|
| Message Trace (4hr) | Trace emails from sender in last 4 hours - shows delivery status per recipient |
| Message Trace (24hr) | Same but last 24 hours |
| Check Safe Senders | Compare TrustedSendersAndDomains across all 3 target mailboxes - identifies why some users get emails without quarantine |
| Add Safe Sender (All) | Add blancoitservices.net to TrustedSendersAndDomains for all 3 users |

#### Policies & Rules
| Button | Description |
|--------|-------------|
| Transport Rules | Show enabled transport rules matching sender domain or phish-related names |
| Allow List | Show Tenant Allow/Block List entries (senders) |
| Anti-Spam Policy | Show HighConfidencePhishAction, PhishSpamAction, AllowedDomains, AllowedSenders |
| Anti-Phish Policy | Show phishing threshold, spoof intelligence, mailbox intelligence settings |
| Compare Users | Compare spam/phish rule assignments across pblanco, kmarchese, mfrank |
| Safe Links | Show Safe Links policies with URL rewrite and click tracking settings |

#### Allow List & Overrides
| Button | Description |
|--------|-------------|
| Add to Allow List | Add sender address to Tenant Allow List (no expiration) |
| Allow Domain | Add sender domain to Tenant Allow List |
| Setup Phish Sim Override | Create Advanced Delivery PhishSimOverridePolicy - bypasses ALL filtering including High Confidence Phish |
| Check Override Status | Show current PhishSimOverridePolicy and rule configuration |
| Connection Filter | Show IP Allow/Block lists in connection filter policy |

#### GoPhish Campaign Management
| Button | Description |
|--------|-------------|
| Campaign Status | Show last 5 campaigns with sent/clicked/submitted counts |
| Latest Results | Show per-recipient results (email, status, IP) for most recent campaign |
| New Campaign (All) | Launch campaign to all 3 targets (Peter, Kevin, Matt) using current tunnel URL |
| Test (Peter Only) | Launch test campaign to pblanco@equippers.com only |
| View Templates | List all email templates, landing pages, and sending profiles in GoPhish |
| SMTP Settings | Show sending profile details (from address, host, envelope sender) |

#### Tunnel & DNS
| Button | Description |
|--------|-------------|
| Start Tunnel | Launch cloudflared tunnel to localhost:80, auto-capture public URL |
| Check Tunnel | Verify cloudflared, Docker Desktop, and GoPhish container are running |
| Check DNS (SPF/DMARC) | Query SPF, DMARC, and MX records for sender domain |
| Set Tunnel URL | Manually enter/update the Cloudflare tunnel URL for campaigns |
| Change Sender | Update GoPhish sending profile from address via input dialog |

### GUI Config (hardcoded at top of script)
- **Sender:** support@expertimportersllc.com
- **GoPhish API:** https://localhost:3333/api
- **Targets:** pblanco@equippers.com, kmarchese@equippers.com, mfrank@equippers.com
- Dark theme with red (#c41230) section headers, green terminal output

## Campaign Tooling Scripts

```
email-admin-gui.ps1        # Windows WinForms GUI for campaign & email management
email-admin-gui-linux.py   # Linux Tkinter GUI (equivalent functionality)
setup-gophish.ps1          # Initial GoPhish API automation (templates, groups, SMTP)
update-gophish.py          # Push templates to GoPhish API (Python - reliable JSON encoding)
launch-campaign.ps1        # CLI campaign launcher with Cloudflare tunnel URL
launch-test-now.ps1        # Quick single-target test campaign launcher
send-peter-only.ps1        # Single-target campaign launcher (Peter only)
send-gmail-test.ps1        # Gmail test campaign launcher
check-api.ps1              # Quick check of all GoPhish API objects (templates, pages, SMTP, groups)
check-campaign.ps1         # Campaign results checker
check-now.ps1              # Check latest campaign results and timeline
update-template.ps1        # GoPhish template management via API
clear-envelope.ps1         # Clear envelope sender on SMTP profile
start-tunnel.ps1           # Start Cloudflare tunnel and capture URL
full-diagnose.ps1          # M365 8-point delivery diagnostic (run after Connect-ExchangeOnline)
diagnose-email-delivery.ps1 # Combined Google + M365 delivery trace with DNS checks
check-email-delivery.ps1   # OAuth device flow email checker via Graph API
run-diagnose.ps1           # Wrapper to connect Exchange and run diagnostics
gui-test.ps1               # Minimal WinForms test (debugging)
send-report.py             # Email campaign results report generator
oci-retry-launch.py        # Retry OCI ARM instance launch until capacity available
templates/
  email-template.html      # Red-branded Equippers password expiration email (Outlook-safe)
  landing-page.html        # M365 login credential capture page with post-submit confirmation (red/black theme)
  password-changed-confirm.html  # Standalone preview of confirmation screen (design reference)
  api-payload-landing.json  # Landing page API payload for GoPhish
  email-payload.json        # Email template API payload for GoPhish
  email-payload-v3.json     # Email template API payload v3
  landing-payload.json      # Landing page payload for GoPhish
```

## Migration Plans

```
Ubuntu-GoPhish-Migration/
  plan.md                    # Full deployment plan for Ubuntu Desktop VM on ESXi
  setup-gophish.sh           # Automated setup: GoPhish + cloudflared + restore + tunnel
  email-template.html        # Email template (copy for server)
  landing-page.html          # Landing page (copy for server)

Windows-Server-2019-Go-Phish-Migration/   # (Abandoned — GoPhish binary bugs, CGO issues)
  plan.md                    # Original Windows Server deployment plan
  setup-gophish-server.ps1   # PowerShell setup script (build from source)
  diag-gophish.ps1           # GoPhish diagnostic script
  fix-config.ps1             # Config/VERSION file fixer
  email-template.html        # Email template (copy for server)
  landing-page.html          # Landing page (copy for server)
```

## Documentation

```
README.md                   # Installation & usage guide
PHISHING_CAMPAIGN_GUIDE.md  # Step-by-step campaign execution guide
PROJECT_SCOPE.md            # Feature completion tracking
plan.md                     # OCI cloud migration plan (superseded by Ubuntu VM plan)
.gitignore                  # Excludes gophish.db, tunnel.log, .playwright-mcp/
```

## GoPhish Access

- **Admin UI:** https://localhost:3333
- **API Key:** Stored in email-admin-gui.ps1 config section (rotated 2026-02-25)
- **Landing page:** http://localhost:80 (use Cloudflare Tunnel or external VM for remote access)
- **SMTP Profile:** "support@expertimportersllc.com" (mail.expertimportersllc.com:465, user/pass auth)
- **Sender domain:** expertimportersllc.com (DNS: SPF, DKIM, DMARC configured via Epik)
- **Sender address:** support@expertimportersllc.com
- **Previous sender:** itsupport@blancoitservices.net (Google SMTP Relay, deprecated)
- **M365 Note:** High Confidence Phish content gets quarantined - use "Release" buttons in GUI or Setup Phish Sim Override

## Cloudflare Tunnel

The install scripts include optional permanent Cloudflare Tunnel setup for fixed campaign URLs.

### Current Configuration
- **Tunnel Name:** gophish
- **Tunnel ID:** be9f9ec3-cd9f-4e82-9f3a-0b4933c37912
- **Public URL:** https://phish.blancoitsolutions.com
- **Config File:** ~/.cloudflared/config.yml
- **Credentials:** ~/.cloudflared/<tunnel-id>.json

### Tunnel Commands
```bash
# Start tunnel (foreground)
cloudflared tunnel run gophish

# Start tunnel (background - Linux)
cloudflared tunnel run gophish &

# Check tunnel status
cloudflared tunnel list

# View tunnel info
cloudflared tunnel info gophish
```

### Setup Flow (built into install scripts)
1. Install cloudflared (auto via apt/chocolatey)
2. Browser login to Cloudflare account
3. Create named tunnel
4. Route DNS to subdomain
5. Save config to ~/.cloudflared/config.yml
6. Save tunnel URL to ~/gophish/tunnel_url.txt

### Quick vs Permanent Tunnels
| Feature | Quick Tunnel | Permanent Tunnel |
|---------|--------------|------------------|
| URL | Random (changes) | Fixed subdomain |
| Old links | Break on restart | Always work |
| Setup | `cloudflared tunnel --url` | One-time via installer |
| Use case | Testing | Production campaigns |

## Email Delivery Notes

- M365 assigns SCL 8 (High Confidence Phish) to phishing template content regardless of transport rules
- Transport rules with SCL -1 do NOT override High Confidence Phish action
- Tenant Allow/Block List alone does not override HPHISH quarantine
- **Working solutions:** Manual quarantine release via GUI, or Advanced Delivery PhishSimOverridePolicy
- Per-user Safe Senders (TrustedSendersAndDomains) can bypass quarantine for individual mailboxes
- Envelope sender with display name causes delivery failures - leave envelope_sender empty in GoPhish
- expertimportersllc.com emails land in inbox (tested 2026-02-25) — SPF/DKIM/DMARC all configured
- **Previous sender (deprecated):** Google SMTP Relay (IP-based auth, blancoitservices.net)

## Landing Page Flow

1. Target clicks phishing link → M365-styled login page (Restaurant Equippers branded)
2. Target enters password → form submits via AJAX (GoPhish captures credentials)
3. "Verifying credentials..." spinner (2 seconds)
4. "Password updated" confirmation screen with green checkmark
5. Progress bar + 8-second countdown → auto-redirect to restaurantequippers.sharepoint.com
6. "Continue to SharePoint" button as manual fallback

**Key technical detail:** Form uses `XMLHttpRequest` to POST credentials in background so the page stays loaded for the confirmation screen. Default GoPhish form POST would redirect immediately, skipping the confirmation.

## Template Updates

Use Python (not PowerShell) to update GoPhish templates - PowerShell's ConvertTo-Json mangles HTML:
```bash
cd C:\Users\pblanco\Documents\AI\gophish-installer && python update-gophish.py
```
GoPhish parses landing page HTML as Go templates - avoid `{{` in JavaScript (use `indexOf` instead of `includes('{{')`)

## DNS Records (expertimportersllc.com)

- **Registrar:** Epik (DNS managed via Epik console)
- **MX:** mail.expertimportersllc.com (priority 10)
- **SPF:** `v=spf1 +a +mx +ip4:66.223.49.32 +ip4:66.223.49.33 include:_spf.epikwebhosting.com ~all`
- **DKIM:** Two RSA keys at `default._domainkey`
- **DMARC:** `v=DMARC1; p=none; rua=mailto:support@expertimportersllc.com`
- **Note:** Had duplicate SPF record (`v=spf1 a mx ~all`) — removed 2026-02-25

## Server Migration (In Progress)

Migrating from local Docker + Cloudflare quick tunnels to a dedicated Ubuntu VM on ESXi:
- **Target:** Ubuntu 24.04 Desktop VM on datacenter ESXi host
- **Domain:** portal.expertimportersllc.com → Cloudflare named tunnel (CNAME at Epik)
- **Setup script:** `Ubuntu-GoPhish-Migration/setup-gophish.sh`
- **Plan:** See `Ubuntu-GoPhish-Migration/plan.md` for full steps
- **Access:** RDP via TeamViewer — all management done on-box
- **Eliminates:** Docker Desktop, quick tunnels (random URLs), port 7844 office firewall issues
- **Previous attempts:** OCI Always Free (capacity unavailable), Windows Server 2019 (GoPhish binary bugs)

## External Dependencies

- Docker Desktop
- WSL2 (Windows Subsystem for Linux)
- Chocolatey package manager
- GoPhish Docker image (gophish/gophish)
- Cloudflare Tunnel (cloudflared) for remote access
- Exchange Online PowerShell module (ExchangeOnlineManagement)
- Google Workspace (SMTP relay, IP-based auth)
- Microsoft.VisualBasic assembly (for GUI input dialogs)
